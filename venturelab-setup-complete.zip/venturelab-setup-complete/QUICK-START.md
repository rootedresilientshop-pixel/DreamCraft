# 🚀 VentureLab Backend - Ready to Run!

## ⚡ SUPER SIMPLE SETUP (3 Steps)

### Step 1: Extract This Folder
Extract the entire `venturelab-setup-complete` folder to:
```
C:\Users\gardn\VentureLab\
```

So you have:
```
C:\Users\gardn\VentureLab\venturelab-setup-complete\
```

### Step 2: Make Sure Docker Desktop is Running
1. Open Docker Desktop
2. Wait for the whale icon 🐳 to appear in your system tray
3. Make sure it's not still "starting"

### Step 3: Double-Click START-HERE.bat
1. Open File Explorer
2. Go to `C:\Users\gardn\VentureLab\venturelab-setup-complete\`
3. Double-click `START-HERE.bat`
4. Wait 3-4 minutes for setup to complete

That's it! 🎉

## ✅ What Should Happen

The script will:
- ✅ Check Docker is running
- ✅ Clean old Docker cache
- ✅ Build the backend
- ✅ Start database + API
- ✅ Run database migrations
- ✅ Show you the logs

You'll see:
```
✅ Database schema created successfully!
🚀 VentureLab API Server Started
✅ Server is ready to accept requests
```

## 🧪 Test It Works

Open a new Command Prompt and run:
```cmd
curl http://localhost:3000/health
```

You should get:
```json
{"status":"ok","timestamp":"...","uptime":...}
```

## 📝 Next Steps

### Register a User
```cmd
curl -X POST http://localhost:3000/api/auth/register -H "Content-Type: application/json" -d "{\"email\":\"test@venturelab.io\",\"password\":\"password123\",\"firstName\":\"Test\",\"lastName\":\"User\",\"role\":\"creator\"}"
```

### Login
```cmd
curl -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" -d "{\"email\":\"test@venturelab.io\",\"password\":\"password123\"}"
```

Save the `accessToken` from the response!

### Create an Idea
```cmd
curl -X POST http://localhost:3000/api/ideas -H "Content-Type: application/json" -H "Authorization: Bearer YOUR_TOKEN" -d "{\"title\":\"AI Budget Tracker\",\"category\":\"fintech\",\"problem\":\"People overspend\",\"solution\":\"AI predicts spending\"}"
```

## 🛠️ Useful Commands

### View Logs
```cmd
docker-compose logs -f api
```

### Stop Everything
```cmd
docker-compose down
```

### Restart Services
```cmd
docker-compose restart
```

### Start Again (After Stopping)
```cmd
docker-compose up -d
```

## 🐛 Troubleshooting

### Script Says "Docker not running"
1. Open Docker Desktop
2. Wait for it to fully start (green light)
3. Run START-HERE.bat again

### Script Says "Build failed"
Check:
- Do you have internet connection?
- Do you have at least 2GB free disk space?
- Is Docker Desktop fully updated?

### Port 3000 Already in Use
Either:
1. Kill the process using port 3000
2. Or edit `docker-compose.yml` and change `"3000:3000"` to `"3001:3000"`

### Want to Start Completely Fresh
```cmd
docker-compose down -v
docker system prune -a -f
```
Then run START-HERE.bat again

## 📞 Still Having Issues?

Check these files:
- `DOCKER_SETUP.md` - Complete troubleshooting guide
- `README.md` - Full documentation

Or just message me for help!

## ✅ Success Checklist

After running START-HERE.bat:
- [ ] Script completed without errors
- [ ] Saw "Server is ready to accept requests"
- [ ] `curl http://localhost:3000/health` returns success
- [ ] Can register a user
- [ ] Can login and get token

All checked? **You're ready to build VentureLab!** 🚀

---

**This package has everything you need - just extract, open Docker Desktop, and double-click START-HERE.bat!**
